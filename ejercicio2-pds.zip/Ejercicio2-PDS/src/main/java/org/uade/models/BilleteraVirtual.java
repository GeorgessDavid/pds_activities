package org.uade.models;

import org.uade.controllers.ViajeController;
import org.uade.models.paymentMethods.MetodoPago;

import java.util.Date;
import java.util.List;

public class BilleteraVirtual {
    private double saldo;
    private MetodoPago metodoVinculado;
    private List<Operacion> historialPagos;

    public double recargar(double monto) {
        this.saldo += monto;

        return this.saldo;
    }

    public double obtenerSaldo() {
        return this.saldo;
    }

    public List<Operacion> obtenerHistorialPagos() {
        return this.historialPagos;
    }

    public MetodoPago obtenerMetodoVinculado() {
        return this.metodoVinculado;
    }

    public void registrarPago(double monto, int idViaje) {
        Viaje viajeRealizado = ViajeController.getInstance().obtenerViaje(idViaje);

        Operacion op = new Operacion(monto, new Date(), viajeRealizado);

        historialPagos.add(op);
    }
}
