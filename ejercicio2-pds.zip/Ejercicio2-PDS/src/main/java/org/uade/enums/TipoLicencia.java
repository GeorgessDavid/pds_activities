package org.uade.enums;

public enum TipoLicencia {
    A1,
    A2,
    A3,
    B1,
    B2,
    D1,
    E1,
    F1,
    G1,
    G2
}
