package org.uade.models.paymentMethods;

public class TarjetaCredito extends MetodoPago {
}
