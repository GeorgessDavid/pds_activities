package org.uade.models;

public abstract class Usuario {
    protected String dni;
    protected String nombre;
    protected String apellido;
    
    public String obtenerDNI() {
        return this.dni;
    }
    
    public String obtenerNombre() {
        return this.nombre;
    }
    
    public String obtenerApellido() {
        return this.apellido;
    }
}
