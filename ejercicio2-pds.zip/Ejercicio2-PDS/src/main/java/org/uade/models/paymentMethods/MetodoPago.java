package org.uade.models.paymentMethods;

public abstract class MetodoPago {
}
