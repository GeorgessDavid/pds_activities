package org.uade.models;

import java.util.Date;

public class Vehiculo {
    private String patente;
    private Date fechaVTV;
    private String marca;
    private String modelo;

    public String obtenerPatente() {
        return this.patente;
    }

    public Date obtenerFechaVTV() {
        return this.fechaVTV;
    }

    public String obtenerMarca() {
        return this.marca;
    }

    public String obtenerModelo() {
        return this.modelo;
    }
}
