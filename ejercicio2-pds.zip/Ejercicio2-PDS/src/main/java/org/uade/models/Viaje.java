package org.uade.models;

import org.uade.enums.EstadoViaje;

public class Viaje {
    private int id;
    private String origen;
    private String destino;
    private Chofer chofer;
    private Pasajero pasajero;
    private EstadoViaje estado;
    private double monto;

    public Viaje(int id, String origen, String destino, Chofer chofer, Pasajero pasajero, EstadoViaje estado, double monto) {
        this.id = id;
        this.origen = origen;
        this.destino = destino;
        this.chofer = chofer;
        this.pasajero = pasajero;
        this.estado = estado;
        this.monto = monto;
    }

    public int obtenerId() {
        return this.id;
    }

    public String obtenerOrigen() {
        return origen;
    }

    public void asignarOrigen(String origen) {
        this.origen = origen;
    }

    public String obtenerDestino() {
        return destino;
    }

    public void asignarDestino(String destino) {
        this.destino = destino;
    }

    public Chofer obtenerChofer() {
        return chofer;
    }

    public void asignarChofer(Chofer chofer) {
        this.chofer = chofer;
    }

    public Pasajero obtenerPasajero() {
        return pasajero;
    }

    public void asignarPasajero(Pasajero pasajero) {
        this.pasajero = pasajero;
    }

    public EstadoViaje obtenerEstado() {
        return estado;
    }

    public void asignarEstado(EstadoViaje estado) {
        this.estado = estado;
    }

    public double obtenerMonto() {
        return monto;
    }

    public void asignarMonto(double monto) {
        this.monto = monto;
    }
}
