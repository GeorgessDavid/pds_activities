package org.uade.models;

import org.uade.enums.TipoLicencia;

import java.util.Date;

public class Licencia {
    private String dni;
    private Date fechaVencimiento;
    private TipoLicencia tipoLicencia;

    public String obtenerDni() {
        return this.dni;
    }

    public Date obtenerFechaVencimiento() {
        return this.fechaVencimiento;
    }

    public boolean estaVencida() {
        return this.fechaVencimiento.after(new Date());
    }

    public TipoLicencia obtenerTipoLicencia() {
        return this.tipoLicencia;
    }
}
