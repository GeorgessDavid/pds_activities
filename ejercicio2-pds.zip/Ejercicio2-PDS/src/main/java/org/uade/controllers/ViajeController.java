package org.uade.controllers;

import org.uade.models.Viaje;

import java.util.ArrayList;
import java.util.List;

// TODO: Agregar al diagrama.

public class ViajeController {
    private static final ViajeController instance = new ViajeController();
    private List<Viaje> viajes;

    public static synchronized ViajeController getInstance() {
        return instance;
    }

    public List<Viaje> obtenerViajes() {
        return this.viajes;
    }

    public Viaje obtenerViaje(int id) {
        for (Viaje viaje : this.obtenerViajes()) {
            if (viaje.obtenerId() == id) return viaje;
        }

        return null;
    }

    public List<Viaje> obtenerViajesPorChofer(String dni) {
        List<Viaje> viajes = new ArrayList<>();

        for (Viaje viaje: this.obtenerViajes()) {
            if (viaje.obtenerChofer().obtenerDNI().equals(dni)) viajes.add(viaje);
        }

        return viajes;
    }

    public List<Viaje> obtenerViajesPorPasajero(String dni) {
        List<Viaje> viajes = new ArrayList<>();

        for (Viaje viaje: this.obtenerViajes()) {
            if (viaje.obtenerPasajero().obtenerDNI().equals(dni)) viajes.add(viaje);
        }

        return viajes;
    }
}
