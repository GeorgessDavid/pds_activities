package org.uade.enums;

public enum EstadoViaje {
    SOLICITADO,
    EMPEZADO,
    FINALIZADO
}
