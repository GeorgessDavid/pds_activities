package org.uade.models;

import java.util.Date;

public class Operacion {
    private double monto;
    private Date fechaOperacion;
    private Viaje viaje;

    public Operacion(double monto, Date fechaOperacion, Viaje viaje) {
        this.monto = monto;
        this.fechaOperacion = fechaOperacion;
        this.viaje = viaje;
    }

    public double obtenerMonto() {
        return this.monto;
    }

    public Date obtenerFechaOperacion() {
        return this.fechaOperacion;
    }
}
