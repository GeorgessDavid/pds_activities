package org.uade.models;

import java.util.List;

public class Chofer extends Usuario {
    private Viaje viajeAsignado;
    private List<Vehiculo> vehiculos;

    public void aceptarViaje(int id) {}

    public void rechazarViaje(int id) {}

    public Viaje obtenerViajeAsignado() {
        return this.viajeAsignado;
    }

    public void asignarViaje(Viaje viaje) {
        this.viajeAsignado = viaje;
    }

    public List<Vehiculo> obtenerVehiculos() {
        return this.vehiculos;
    }
}
