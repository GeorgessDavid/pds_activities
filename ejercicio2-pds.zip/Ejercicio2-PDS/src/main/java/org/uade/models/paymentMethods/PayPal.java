package org.uade.models.paymentMethods;

public class PayPal extends MetodoPago {
}
