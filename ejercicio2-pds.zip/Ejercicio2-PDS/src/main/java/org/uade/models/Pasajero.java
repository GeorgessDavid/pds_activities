package org.uade.models;

public class Pasajero extends Usuario {
    public void solicitarViaje(String origen, String destino) {
        // TODO...
    }
}
